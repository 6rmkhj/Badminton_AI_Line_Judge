"""Launch the Windows A/B workspace using its prepared GPU or CPU runtime."""
from pathlib import Path
import importlib
import os
import runpy
import subprocess
import sys
import traceback

root = Path(__file__).resolve().parent
app = root / 'app'
try:
    if sys.platform != 'win32' or sys.maxsize <= 2**32:
        raise RuntimeError('Windows 64비트 전용 패키지입니다.')
    environment = app / '.venv'
    prepared_python = environment / 'Scripts' / 'python.exe'
    if prepared_python.is_file() and Path(sys.prefix).resolve() != environment.resolve():
        if not (environment / 'pyvenv.cfg').is_file():
            raise RuntimeError('app/.venv가 올바른 가상환경이 아닙니다. GPU 설치 상태를 확인하세요.')
        os.execv(str(prepared_python), [str(prepared_python), '-X', 'utf8',
                                     str(Path(__file__).resolve()), *sys.argv[1:]])
    os.environ['PATH'] = str(root / 'tools') + os.pathsep + str(root / 'runtime') + os.pathsep + os.environ.get('PATH', '')
    print('배드민턴 A/B 영상 분석을 준비합니다.', flush=True)
    for module in ('numpy', 'cv2', 'scipy', 'filelock'):
        importlib.import_module(module)
    options = {'capture_output': True, 'text': True, 'encoding': 'utf-8', 'errors': 'replace', 'timeout': 30, 'check': True}
    encoders = subprocess.run([str(root / 'tools/ffmpeg.exe'), '-hide_banner', '-encoders'], **options)
    if 'libx264' not in encoders.stdout:
        raise RuntimeError('미리보기 생성에 필요한 H.264 인코더가 없습니다.')
    subprocess.run([str(root / 'tools/ffprobe.exe'), '-version'], **options)
    sys.path.insert(0, str(app))
    os.chdir(app)
    sys.argv = [str(app / 'start.py'), '--pair', '--port', '0', *sys.argv[1:]]
    print('브라우저에서 장치 설정을 확인한 뒤 A/B 영상을 올리세요. 종료하려면 Ctrl+C를 누르세요.', flush=True)
    runpy.run_path(str(app / 'start.py'), run_name='__main__')
except KeyboardInterrupt:
    pass
except Exception:
    error = traceback.format_exc()
    (root / 'startup-error.log').write_text(error, encoding='utf-8')
    print('실행하지 못했습니다. 같은 폴더의 startup-error.log를 확인해 주세요.', file=sys.stderr)
    print(error, file=sys.stderr)
    raise SystemExit(1)
